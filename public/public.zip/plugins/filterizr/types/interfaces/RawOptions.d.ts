import { BaseOptions } from './BaseOptions';
export interface RawOptions extends BaseOptions {
    filter?: string | string[];
}
