<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
        	Administrar restaurantes <a href="<?php echo e(url('restaurant/create')); ?>" class="btn btn-primary float-right">Nuevo restaurantes</a>
        </div>

        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <table class="table table-bordered table-stripped mt-4">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Direccion</th>
                    <th>Telefono</th>
                    <th>Foto</th>
                    <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($restaurant->id); ?></td>
                        <td><?php echo e($restaurant->name); ?></td>
                        <td><?php echo e($restaurant->address); ?></td>
                        <td><?php echo e($restaurant->telephone); ?></td>
                        <td><img src="<?php echo e(asset($restaurant->picture)); ?>" alt="" width="90px"></td>
                        <td >
                            <a href="<?php echo e(route('restaurant.edit', $restaurant->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a> |
                            <form action="<?php echo e(route('restaurant.destroy', $restaurant->id)); ?>" method="POST" class="float-right">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </button>

                            </form>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/duvg/projects/festipizza/resources/views/restaurant/index.blade.php ENDPATH**/ ?>