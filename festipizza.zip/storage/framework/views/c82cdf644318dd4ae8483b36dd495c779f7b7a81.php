<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card">
        <div class="card-header">
        	Administrar pizzas <a href="<?php echo e(url('pizza/create')); ?>" class="btn btn-primary float-right">Nueva pizza</a>
        </div>

        <div class="card-body">

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <table class="table table-bordered table-stripped mt-4">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>ingredientes</th>
                    <th>Foto</th>
                    <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                	<?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pizza->id); ?></td>
                        <td><?php echo e($pizza->name); ?></td>
                        <td><?php echo e($pizza->description); ?></td>
                        <td><?php echo e($pizza->ingredients); ?></td>
                        <td><img src="<?php echo e(asset($pizza->picture)); ?>" alt="" width="90px"></td>
                        <td >
                            <a href="<?php echo e(route('pizza.edit', $pizza->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a> |
                            <form action="<?php echo e(route('pizza.destroy', $pizza->id)); ?>" method="POST" class="float-right">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </button>

                            </form>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/duvg/projects/festipizza/resources/views/pizza/index.blade.php ENDPATH**/ ?>