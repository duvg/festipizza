<?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                Administrar restaurantes
            </div>

            <form role="form" method="post" action="<?php echo e(route('restaurant.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card-body">

                    <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nombre</label>
                            <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Nombre del restaurante">
                            <?php if($errors->has('name')): ?>
                                <div class="error"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="address">Direccion</label>
                            <input type="text" name="address" class="form-control" id="address" placeholder="Direccion">
                            <?php if($errors->has('address')): ?>
                                <div class="error"><?php echo e($errors->first('address')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="telephone" >Telefono</label>
                            <input type="text" name="telephone" class="form-control" id="address" placeholder="Teledono">
                            <?php if($errors->has('telephone')): ?>
                                <div class="error"><?php echo e($errors->first('telephone')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputFile">Foto</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="picture" name="picture">
                                    <label class="custom-file-label" for="exampleInputFile">Seleccionar imagen</label>
                                    <?php if($errors->has('picture')): ?>
                                        <div class="error"><?php echo e($errors->first('picture')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5">

                        <img src="" alt="" id="imagepreview" style="height: 370px;">
                    </div>
                    </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <a href="<?php echo e(url('restaurant/index')); ?>" class="btn btn-primary float-right">Regresar al listaoo</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function(e) {
                        $('#imagepreview').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#picture").change(function() {
                readURL(this);
            });
        });

    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/duvg/projects/festipizza/resources/views/restaurant/form.blade.php ENDPATH**/ ?>